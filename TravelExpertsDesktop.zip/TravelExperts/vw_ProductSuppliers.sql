CREATE VIEW dbo.vw_ProductSuppliers
	AS
SELECT ps.ProductSupplierId, ps.ProductId, p.ProdName, ps.SupplierId, s.SupName
  FROM dbo.Products_Suppliers ps
		JOIN
		dbo.Suppliers s ON ps.SupplierId = s.SupplierId
		JOIN
		dbo.Products p on ps.ProductId= p.ProductId;