﻿/* Purpose: Form to enter data into Package Table.
 * Author: Priya P
 * Data: 16Sep2021
 * Table: Packages
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

using System.Linq;
using System.Text;

using System.Windows.Forms;
using TravelExpertsData;

namespace TravelExperts
{
    
    public partial class frmPackage : Form
    {
        public bool isAdd; //form opened for add-true or modify-false
        public int PackageId = 0;// package selected in modify mode
        private Package package;
        private List<PackagesProductsSupplier> pkgPdtSuppliers;//list for packageproductsuppliers
        private List<ProductDTO> products;//list of products
        private List<ProductSuppliersDTO> productsSuppliers;//list of product suppleirs
        private List<Supplier> suppliers;//list of suppliers
        public frmPackage()
        {
            InitializeComponent();
        }
        //to clear the form controls
        private void btnClear_Click(object sender, EventArgs e)
        {
             ClearControls();
            
            
        }
        /* Method: ClearControls
         * Purpose: To clear all controls in the form
         *          Reset selected values in the list boxes and clean up the list view.
         */
        private void ClearControls()
        {
            txtPackageId.Clear();//clear packageId
            txtPkgName.Clear();//clear package name
            txtPkgDesc.Clear();//clear package description
            txtBasePrice.Clear();//clear base price
            txtCommission.Clear();//clear commission
            txtImageLocation.Clear();//clear image location
            dtpStartDate.Value = DateTime.Today;//reset package start date
            dtpEndDate.Value = DateTime.Today; //reset package end date
            lvwPackageProducts.Items.Clear(); // clear list view of package product suppliers
            lstProducts.SelectedIndex = -1; //change selection of products list
            lstProductSupplier.SelectedIndex = -1;//change select of supplier list

        }

        //loads the form and collects all data needed for the form
        private void frmPackage_Load(object sender, EventArgs e)
        {

            try
            {
                if (isAdd)//form loaded in Add mode
                {
                    lblPackageInfo.Text = "New Package";
                    dtpStartDate.MinDate = DateTime.Today.Date; //set min date only for new package
                    dtpEndDate.MinDate = DateTime.Today.Date; //set min date only for new package
                }
                else //form loaded in Modify mode
                {
                    dtpStartDate.MinDate = new DateTime(2000, 01, 01);
                    ; //set min date only for new package
                    dtpEndDate.MinDate = new DateTime(2000, 01, 01);  //set min date only for new package

                    lblPackageInfo.Text = "Update Package";
                    LoadData(); //load existing package data
                }
                GetProductList(); //get the list of products and fill the listbox
                ListViewFormat(); //format the list view
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error when loading data: {ex.Message}",
               ex.GetType().ToString());

            }
        }

        /* Method: ListViewFormat
         * Purpose: To format the list view for package product suppliers
         * Referred in: frmPackage_Load
         */
        private void ListViewFormat()
        {

            lvwPackageProducts.Columns.Add("Product Name", 280); //first column header and width
            lvwPackageProducts.Columns.Add("Supplier Name", 280);//second column header and width
            lvwPackageProducts.Columns.Add("PS_Id", 0);//third column header and width
            
            lvwPackageProducts.View = View.Details; //set the style of list view
            lvwPackageProducts.GridLines = true;//show grid lines
            lvwPackageProducts.FullRowSelect = true; //allow full row selection
            lvwPackageProducts.MultiSelect = false; //do not allow multiselect

        }//close ListViewFormat

        /* Method: LoadData
         * Purpose: To load data into form controls for an existing package in update mode
         */
        private void LoadData()
        {
            try
            {
                package = PackageManager.GetPackage(PackageId); //get details of package based on id
                if (package != null)
                {//set form control data from the object
                    txtPackageId.Text = package.PackageId.ToString();
                    txtPkgName.Text = package.PkgName;
                    txtPkgDesc.Text = package.PkgDesc;
                    txtBasePrice.Text = package.PkgBasePrice.ToString("N2");
                    txtCommission.Text = package.PkgAgencyCommission?.ToString("N2");
                    txtImageLocation.Text = package.PkgImageLocation;
                    

                    dtpStartDate.Value = (DateTime)package.PkgStartDate;
                    dtpEndDate.Value = (DateTime)package.PkgEndDate;
                    setPackageSupplierList(PackageId); //set the package product supplier list (list view data)
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error getting package details: {ex.Message}",
                               ex.GetType().ToString());
            }

        }
        /* Method: setPackageSupplierList
         * Purpose: To get data from database for package product suppliers and setup data in list view
         * Referred in : LoadData()
         */
        private void setPackageSupplierList(int pkgId)
        {
            try
            {
                List<PackageProductsSuppliersDTO> pkgPdtSupplier;
                pkgPdtSupplier = PackageManager.GetPackageProductsSuppliers(pkgId);//get all package product suppliers for package id
                                                                                   //setup data in list view
                foreach (PackageProductsSuppliersDTO pps in pkgPdtSupplier)
                {
                    ListViewItem lvi = new ListViewItem(pps.ProdName);
                    lvi.SubItems.Add(pps.SupName);
                    lvi.SubItems.Add(pps.ProductSupplierId.ToString());
                    lvwPackageProducts.Items.Add(lvi); //add the new list item to list
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error when retrieving data: {ex.Message}",
               ex.GetType().ToString());


            }
        }

         /*  Method: GetProductList
          *  Purpose: To load data in the listbox for products
          *  Referred in: frmPackage_Load
          */
        private void GetProductList()
        {

            products = ProductManager.GetProducts();//get all products
            productsSuppliers = ProductManager.GetProductSuppliers();//get all product supliers
            suppliers = SupplierManager.GetSuppliers(); //get all suppliers
            //load data in products list
            if (products != null)
            {
                lstProducts.DataSource = products;
                lstProducts.DisplayMember = "ProdName";
                lstProducts.ValueMember = "ProductId";
                int pdtId = (int)lstProducts.SelectedValue;
                GetProductSupplierList(pdtId);
                
            }
            

        }
        /* Method: GetProductSupplierList
        *  Purpose: To load data in the suppliers list
        *  Referred in: GetProductList, lstProducts_Click
        */
        private void GetProductSupplierList(int ProductId)
        {
            List<ProductSuppliersDTO> selectProdSuppliers;
            selectProdSuppliers = productsSuppliers.FindAll(p => p.ProductId == ProductId);//filter product suppliers by product id
            //load data in product suppliers list box
            if (selectProdSuppliers != null)
            {
                
                var PdtSupplier = suppliers
                                    .Join(selectProdSuppliers,
                                    s=> s.SupplierId,
                                    ps => ps.SupplierId,
                                    (s,ps) => new
                                    {
                                        SupplierName = s.SupName,
                                        PdtSupId = ps.ProductSupplierId,
                                        PdtId = ps.ProductId
                                    }).ToList();


                lstProductSupplier.DataSource = PdtSupplier;
                
                lstProductSupplier.DisplayMember = "SupplierName";
                lstProductSupplier.ValueMember = "PdtSupId";

            }
        }
        //save data to the database after validations
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (Validator.IsPresent(txtPkgName, "Data Validation Error") &&
                Validator.IsPresent(txtPkgDesc, "Data Validation Error") &&
                Validator.IsPresent(txtBasePrice, "Data Validation Error") &&
                Validator.IsNonNegativeDecimal(txtBasePrice, "Data Validation Error") &&
                Validator.IsPresent(txtCommission, "Data Validation Error") &&
                Validator.IsNonNegativeDecimal(txtCommission, "Data Validation Error")
                )
            {
                if (DataValidation())//additional validations on date
                {   // MessageBox.Show("Valid");
                    SaveData();
                    ClearControls();
                    
                }            
            }
        }

        /* Method: SaveData
         * Purpose: To save data in the form
         * Referred in: btnSave_Click
         */
        private void SaveData()
        {
            if (isAdd)//form opened in Add mode
            {
                package = new Package();
            }
            package.PkgName = txtPkgName.Text.Trim(); //trim packagename before saving
            package.PkgDesc = txtPkgDesc.Text.Trim();//trim package desc before saving
            package.PkgStartDate =dtpStartDate.Value.Date; //set start date
            package.PkgEndDate = dtpEndDate.Value.Date;//set end date
            package.PkgBasePrice = Convert.ToDecimal(txtBasePrice.Text);//set baseprice
            package.PkgAgencyCommission = Convert.ToDecimal(txtCommission.Text); //set commission
            package.PkgImageLocation = txtImageLocation.Text.Trim();//set image location
            try
            {
                if (isAdd)//new data - add
                {
                    PackageId = PackageManager.addPackage(package); //if form opened in Add mode, add Package
                }
                else//form opened in edit mode
                {
                    PackageManager.updatePackage(package);//update the package
                }
                if (lvwPackageProducts.Items.Count > 0) //if items are selected for package supplier details
                    //save package product suppliers
                    SavePackageProdSuppliers(PackageId); //save package products.

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error when adding new package: {ex.Message}",
                               ex.GetType().ToString());
            }

        }
        /* Method: SavePackageProdSuppliers
         * Purpose: To save package product suppliers
         * Save data in the list view - details of package product suppliers
         * Parameter:package id
         */
        private void SavePackageProdSuppliers(int pkgId)
        {

            pkgPdtSuppliers = new List<PackagesProductsSupplier>();
            for (int i = 0; i < lvwPackageProducts.Items.Count; i++) //loop through each row in list view
            {
                PackagesProductsSupplier pps = new PackagesProductsSupplier();
                pps.PackageId = pkgId; //add package id
                pps.ProductSupplierId = Convert.ToInt32(lvwPackageProducts.Items[i].SubItems[2].Text);//add product supplier code
                pkgPdtSuppliers.Add(pps);
            }
            if (!isAdd) //if package opened in Update mode
                PackageManager.delPackagePdtsSuppliers(pkgId);//delete existing package product supplier rows from database
            PackageManager.addPackagePdtsSuppliers(pkgPdtSuppliers);//add new set of package product suppliers
        }

        /* Method: DataValidation
         * Purpose: Additional data validation outside of validator class
         * 
         */
        private bool DataValidation()
        {
            bool isValid = true;
            //start date must be less than end date of travel
            if (dtpStartDate.Value >= dtpEndDate.Value)
            {
                MessageBox.Show(dtpStartDate.Tag + " must be less than " + dtpEndDate.Tag, "Data Validation Error");
                dtpStartDate.Focus();
                isValid = false;
            }
            else if (Convert.ToDecimal(txtBasePrice.Text) <= Convert.ToDecimal(txtCommission.Text))
            {
                MessageBox.Show(txtCommission.Tag+ " must be less than " + txtBasePrice.Tag, "Data Validation Error");
                txtCommission.Focus();
                isValid = false;
            }

            return isValid;
        }


        private void txtPkgName_KeyPress(object sender, KeyPressEventArgs e)
        {
            //e.KeyChar is the character associated with the key pressed
            //e.Handled is a bool flag indicating that the process is complete
            // if (character not valid)
            if (!Char.IsLetter(e.KeyChar) && //not a letter
                e.KeyChar != ' ' && //not a space
                e.KeyChar != '-' && //not a hyphen
                e.KeyChar != '.' && //not a dot
                e.KeyChar != '\'' && //not an apostrophe
                e.KeyChar != (char)Keys.Back //not a backspace
                )
            {
                e.Handled = true;//ignore it (mark is handled)
            }

        }

        private void txtPkgDesc_KeyPress(object sender, KeyPressEventArgs e)
        {
            //e.KeyChar is the character associated with the key pressed
            //e.Handled is a bool flag indicating that the process is complete
            // if (character not valid)
            if (!Char.IsLetter(e.KeyChar) && //not a letter
                !Char.IsDigit(e.KeyChar) &&//not a number
                e.KeyChar != ' ' && //not a space
                e.KeyChar != '-' && //not a hyphen
                e.KeyChar != '.' && //not a dot
                e.KeyChar != '*' && //not a *
                e.KeyChar != '+' && //not a +
                e.KeyChar != ',' && //not a ,
                e.KeyChar != '\'' && //not an apostrophe
                e.KeyChar != (char)Keys.Back //not a backspace
                )
            {
                e.Handled = true;//ignore it (mark is handled)
            }

        }

        private void txtBasePrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            //e.KeyChar is the character associated with the key pressed
            //e.Handled is a bool flag indicating that the process is complete
            // if (character not valid)
            if (!Char.IsDigit(e.KeyChar) && //not a letter
                e.KeyChar != '.' && //not a dot
                e.KeyChar != (char)Keys.Back //not a backspace
                )
            {
                e.Handled = true;//ignore it (mark is handled)
            }
        }

        private void txtCommission_KeyPress(object sender, KeyPressEventArgs e)
        {
            //e.KeyChar is the character associated with the key pressed
            //e.Handled is a bool flag indicating that the process is complete
            // if (character not valid)
            if (!Char.IsDigit(e.KeyChar) && //not a letter
                e.KeyChar != '.' && //not a dot
                e.KeyChar != (char)Keys.Back //not a backspace
                )
            {
                e.Handled = true;//ignore it (mark is handled)
            }
        }


        //remove an item from list view for package product suppliers
        private void btnRemove_Click(object sender, EventArgs e)
        {
            ListView.SelectedIndexCollection indexes = lvwPackageProducts.SelectedIndices;//get the collection of selected items from the list view
            
            foreach (int index in indexes)//will be only 1 item as multiselect is false.
            {
                lvwPackageProducts.Items.RemoveAt(index);
                
            }

        }
        //load product details into list
        private void lstProducts_Click(object sender, EventArgs e)
        {
            if (lstProducts.SelectedIndex != -1)
            {
                int pdtId = (int)lstProducts.SelectedValue;
                GetProductSupplierList(pdtId);//load related suppliers for the selected product id
            }
        }
        //close package form
        private void btnClose_Click(object sender, EventArgs e)
        {
            
                this.Close();  //exit form
        }

        //add data from product and product supplier to list view
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (lstProducts.SelectedIndex != -1 && lstProductSupplier.SelectedIndex != -1)
            {
                int psId = Convert.ToInt32(lstProductSupplier.SelectedValue);
                if (!DupProductSupplier(psId))//check if the product supplier is already selected.
                    AddProductSupplier();
                else
                    MessageBox.Show("This product-supplier is already selected.", "Data Validation Error");

            }
        }
        /* Method: AddProductSupplier
         * Purpose: To add product suppliers to list
         */
        private void AddProductSupplier()
        {
            ListViewItem lvi = new ListViewItem(lstProducts.GetItemText(lstProducts.SelectedItem));//add selected product
            lvi.SubItems.Add(lstProductSupplier.GetItemText(lstProductSupplier.SelectedItem));//add selected product supplier name
            lvi.SubItems.Add(lstProductSupplier.SelectedValue.ToString());//add selected product supplier name
            lvwPackageProducts.Items.Add(lvi); //add the new list item to list
        }

        /* Method: DupProductSupplier
         * Purpose: To check if the product supplier id already exists in the list
         */
        private bool DupProductSupplier(int psID)
        {
            int inListPsId = 0;
            bool isDupe = false;
            for (int i = 0; i < lvwPackageProducts.Items.Count; i++) //loop through each row in list view
            {

                inListPsId = Convert.ToInt32(lvwPackageProducts.Items[i].SubItems[2].Text);//add product supplier code
                if (inListPsId == psID)
                { 
                    isDupe = true;
                    break;
                }
            }

            return isDupe;
        }
    } //close class
}//close namespace
