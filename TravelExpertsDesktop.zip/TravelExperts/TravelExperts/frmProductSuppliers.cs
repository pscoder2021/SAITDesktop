﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TravelExpertsData;

/*
 * frmProductSuppliers - form to add/delete/modify product supplier and supplier tables
 * David Grant
 * 2021/09/16
 */

namespace TravelExperts
{
    public partial class frmProductSuppliers : Form
    {
        private int _prodId; // ProductId
        private string _supId; // SupplierId
        private string _prodSupId; // ProductSupplierId
        private int _maxId = 0; // Highest id in supplier table, table set as non incremental

        DataManager dataManager = new DataManager();
        public string selected; // To display current grid selection to user
        public frmProductSuppliers()
        {
            InitializeComponent();
        }

        /// <summary>
        /// On load set comboboxes to first value, and display gridview items
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmProductSuppliers_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            displayItems();
            cmbProd.SelectedIndex = 0;
            dgvItems.Columns[1].Width = 275;
        }

        /// <summary>
        /// Display grid view items
        /// </summary>
        private void displayItems()
        {
            using (TravelExpertsContext db = new TravelExpertsContext())
            {
                var productSuppliers = db.ProductsSuppliers.AsEnumerable().ToList();
                var suppliers = db.Suppliers.AsEnumerable().ToList();
                var products = db.Products.AsEnumerable().ToList();

                // Join the three tables and query relevant columns
                var items = from p in productSuppliers
                            join s in suppliers
                            on p.SupplierId equals s.SupplierId
                            join pr in products
                            on p.ProductId equals pr.ProductId
                            select new
                            {
                                productName = pr.ProdName,
                                supplierName = s.SupName,
                                supplierId = s.SupplierId,
                                productId = pr.ProductId,
                                prodSupId = p.ProductSupplierId
                            };

                dgvItems.DataSource = items.ToList();

                // Populate combobox
                foreach  (Product p in products)
                {
                    cmbProd.Items.Add(p.ProdName);
                }

                // Get highest supplier id
                foreach (Supplier s in suppliers)
                {
                    if (s.SupplierId > _maxId)
                        _maxId = s.SupplierId;
                }
                
            }
        }

        /// <summary>
        /// On cell click gather user selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvItems_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (comboBox1.SelectedIndex != 0 && dgvItems.SelectedRows.Count != 0)
            {
                DataGridViewRow row = this.dgvItems.SelectedRows[0];
                txtSupplierName.Text = row.Cells["supplierName"].Value.ToString();
                cmbProd.SelectedItem = row.Cells["productName"].Value;

                _supId = row.Cells["supplierId"].Value.ToString();
                _prodSupId = row.Cells["prodSupId"].Value.ToString();
            }
        }

        /// <summary>
        /// Cancel button, dispose form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Form.ActiveForm.Dispose();
        }

        /// <summary>
        /// Ok button, call DataManager class to add/modify/delete 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOk_Click(object sender, EventArgs e)
        {
            if (Validator.IsPresentCbm(cmbProd, cmbProd.SelectedItem.ToString()) && Validator.IsPresent(txtSupplierName,txtSupplierName.Text))
            {
                Product product = new Product();
                Supplier supplier = new Supplier();
                ProductsSupplier prodSup = new ProductsSupplier();

                supplier.SupName = txtSupplierName.Text;
              //  supplier.SupplierId = _maxId + 1;
                product.ProdName = cmbProd.SelectedItem.ToString();
                product.ProductId = getProdId();

                if (comboBox1.SelectedIndex == 0) // Add
                {
                    try
                    {
                        dataManager.addItem(product,supplier);
                        MessageBox.Show("New item added successfully");
                        txtSupplierName.Text = null;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error when adding to db: {ex.Message}",
                                        ex.GetType().ToString());
                    }
                }
                else if (comboBox1.SelectedIndex == 1) // Modify
                {
                    supplier.SupplierId = Int32.Parse(_supId);
                    prodSup.ProductSupplierId = Int32.Parse(_prodSupId);

                    try
                    {
                        dataManager.modifyItem(product, supplier, prodSup);
                        MessageBox.Show("Item modified successfully");
                        txtSupplierName.Text = null;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error when modifying db: {ex.Message}",
                                        ex.GetType().ToString());
                    }
                }
                else // Delete
                {
                    supplier.SupplierId = Int32.Parse(_supId);
                    prodSup.ProductSupplierId = Int32.Parse(_prodSupId);

                    DialogResult answer = MessageBox.Show($"Are you sure to delete?",
                    "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (answer == DialogResult.Yes) // confirmed
                    {
                        try
                        {
                            dataManager.deleteItem(product, supplier, prodSup);
                            MessageBox.Show("Item deleted successfully");
                            txtSupplierName.Text = null;
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error when deleting in db: {ex.Message}",
                                        ex.GetType().ToString());
                        }
                    }
                }

                displayItems();
            }


        }

        /// <summary>
        /// return new productId
        /// </summary>
        /// <returns></returns>
        private int getProdId()
        {
            return cmbProd.SelectedIndex + 1;
        }
        private void cmbProd_SelectedIndexChanged(object sender, EventArgs e)
        {
            _prodId = getProdId();
        }
    }
}
