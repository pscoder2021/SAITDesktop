﻿/* Purpose: Add/Modify/Delete product table data
 * Code Author: Priya P
 * Form Design: Maureen B
 * Date: 25-Sep-21
 */
using TravelExpertsData;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace TravelExperts
{
    public partial class frmAddModifyProduct : Form
    {
        private bool isAdd;
        private Product product;

        public frmAddModifyProduct()
        {
            InitializeComponent();
        }
        //load list with products from table
        private void frmAddModifyProduct_Load(object sender, EventArgs e)
        {
            isAdd = true;
           GetProductList();
            ResetControls();
        }
        /* Method: GetProductList()
         * Purpose: To get a list of products 
         * Uses: Product Manager
         */
        private void GetProductList()
        {
            List<ProductDTO> products;
            products = ProductManager.GetProducts();//get all products
            if (products != null) //list is not empty
            {
                lstProducts.DataSource = products; //fill listbox with products
                lstProducts.DisplayMember = "ProdName";//field to display
                lstProducts.ValueMember = "ProductId";//field to save value
            }
        }
        //Modify existing data by selecting an item from product listbox
        private void btnModify_Click(object sender, EventArgs e)
        {
            if (lstProducts.SelectedIndex != -1) //some value is selected in the listbox
            {
                txtProductID.Text = lstProducts.SelectedValue.ToString(); //get product id
                txtProductName.Text = lstProducts.GetItemText(lstProducts.SelectedItem);//get product name
                btnDelete.Enabled = true;
                isAdd = false; //modify mode 
            }
        }
        /* Method: ResetControls()
         * Purpose: to clear form controls
         * Author: Maureen B
         */
        private void ResetControls()
        {
            txtProductID.Text = "";
            txtProductName.Text = "";
            lstProducts.SelectedIndex = -1;
            btnModify.Enabled = false;
            btnDelete.Enabled = false;
            isAdd = true;
            
        }
        //close current form
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //Save Product data includes New and Updated
        //Author:Priya P
        private void btnSave_Click(object sender, EventArgs e)
        {
            int ProductId = 0;
            if (Validator.IsPresent(txtProductName, "Data Validation Error"))//check if data entered for product name
            {
                try
                {
                    if (isAdd)//add mode
                    {
                        product = new Product();
                        product.ProdName = txtProductName.Text.Trim();//product name
                        ProductId = ProductManager.addProduct(product);//saves new product
                        
                    }
                    else//update mode
                    {
                        ProductId = Convert.ToInt32(txtProductID.Text);//code for the product to be updated
                        ProductManager.updateProduct(ProductId, txtProductName.Text.Trim());//updates the product
                    }
                    GetProductList();//refresh product list
                    ResetControls();//reset controls to clear
                }
                catch (Exception ex)
                {

                    MessageBox.Show($"Error when adding new package: {ex.Message}",  ex.GetType().ToString());
                }


                
            }
        }
        //enable Modify button when an item is selected in the list
        private void lstProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnModify.Enabled = true;
        }
        //clear form controls
        private void btnClear_Click(object sender, EventArgs e)
        {
            ResetControls();
        }
        //delete a product
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtProductName.Text != "")//check if a product is selected from the list
            {
                //confirm delete
                DialogResult button = MessageBox.Show(
                                $"Are you sure you want to delete {txtProductName.Text}?", "Confirm Action",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
                if (button == DialogResult.Yes)
                {
                    int ProductId = Convert.ToInt32(txtProductID.Text);
                    if (ProductManager.prodDependencies(ProductId))//check if there are dependencies in product supplier table
                    {//no dependencies in product supplier table
                        try
                        {//delete product
                            ProductManager.delProduct(ProductId);

                            GetProductList();//refresh product list
                            ResetControls();//reset controls to clear
                        }
                        catch (Exception ex)
                        {

                            MessageBox.Show($"Error when adding new package: {ex.Message}", ex.GetType().ToString());
                        }
                    }
                    else
                    {//has dependencies
                        MessageBox.Show($"{txtProductName.Text} has Suppliers attached, cannot delete!", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            else
            {//no product was selected.
                MessageBox.Show("Select a product to delete!", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//end delete 
    }//end class
}//end namespace
