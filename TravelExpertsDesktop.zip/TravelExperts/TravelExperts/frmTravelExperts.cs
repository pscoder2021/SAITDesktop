﻿/* Purpose: Master form for Travel Experts Desktop application.
 * Author: Priya P
 * Date: 05Sep2021
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TravelExperts
{
    public partial class frmTravelExperts : Form
    {
        public frmTravelExperts()
        {
            InitializeComponent();
        }

    
        //load form with date/time showing in the taskbar
        private void frmTravelExperts_Load(object sender, EventArgs e)
        {
            tssDate.Text = DateTime.Today.ToLongDateString();
            tssTime.Text = DateTime.Now.ToLongTimeString();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            tssTime.Text = DateTime.Now.ToLongTimeString();
        }
        //load the list of travel packages form
        private void packagesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTravelPackages TPackageForm = new frmTravelPackages();
            TPackageForm.StartPosition = FormStartPosition.CenterScreen;
            TPackageForm.MdiParent = this;
            TPackageForm.Show();
        }
        //load the product form
        private void productsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAddModifyProduct ProductForm = new frmAddModifyProduct();
            ProductForm.StartPosition = FormStartPosition.CenterScreen;
            ProductForm.MdiParent = this;
            ProductForm.Show();
        }

        private void suppliersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProductSuppliers frmProductSuppliers = new frmProductSuppliers();
            frmProductSuppliers.StartPosition = FormStartPosition.CenterScreen;
            frmProductSuppliers.MdiParent = this;
            frmProductSuppliers.Show();
        }
    }
}
