﻿/* Class Name: Validator
 * Purpose: To validate input data entered on form controls.
*/
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace TravelExperts
{
    /// <summary>
    /// A repository of validation methods
    /// </summary>
    /// 
    
    public static class Validator
    {
        /// <summary>
        /// checks if textbox has anything in it
        /// </summary>
        /// <param name="tb">text box to validate</param>
        /// <returns>true if valid, and false if not</returns>
        public static bool IsPresent(TextBox tb, string msgTitle)
        {
            bool isValid = true;
            if((String.IsNullOrEmpty(tb.Text)) || (String.IsNullOrWhiteSpace(tb.Text)))// empty
            {
                MessageBox.Show(tb.Tag + " is required.", msgTitle);
                tb.Focus(); 
                isValid = false;
            }
            
            return isValid;
        }

        public static bool IsPresentCbm(ComboBox tb, string msgTitle)
        {
            bool isValid = true;
            if ((String.IsNullOrEmpty(tb.Text)) || (String.IsNullOrWhiteSpace(tb.Text)))// empty
            {
                MessageBox.Show(tb.Tag + " is required.", msgTitle);
                tb.Focus();
                isValid = false;
            }

            return isValid;
        }

        /// <summary>
        /// checks if a textbox contains whole number that is greater than or equal to zero
        /// </summary>
        /// <param name="tb">textbox to validate</param>
        /// <returns>true if valid, and false if not</returns>
        public static bool IsNonNegativeInt(TextBox tb, String msgTitle)
        {
            bool isValid = true;
            int value;
            if(!Int32.TryParse(tb.Text, out value)) // if the content cannot be  parsed as int
            {
                MessageBox.Show(tb.Tag + " has to be a whole number", msgTitle);
                tb.SelectAll();
                tb.Focus();
                isValid = false;
            }
            else if(value < 0 ) // int, but negative
            {
                MessageBox.Show(tb.Tag + " cannot be negative.", msgTitle);
                tb.SelectAll();
                tb.Focus();
                isValid = false;
            }
            return isValid;
        }

        /// <summary>
        /// checks if a textbox contains whole number within range
        /// </summary>
        /// <param name="tb">textbox to validate</param>
        /// <param name="minValue">minimum value allowed</param>
        /// <param name="maxValue">maximum value allowed</param>
        /// <returns>true if valid, and false if not</returns>
        public static bool IsIntInRange(TextBox tb, int minValue, int maxValue, String msgTitle)
        {
            bool isValid = true;
            int value;
            if (!Int32.TryParse(tb.Text, out value)) // if the content cannot be  parsed as int
            {
                MessageBox.Show(tb.Tag + " has to be a whole number.", msgTitle);
                tb.SelectAll();
                tb.Focus();
                isValid = false;
            }
            else if (value < minValue || value > maxValue) // int, but outside the range
            {
                MessageBox.Show(tb.Tag + $" has to be between {minValue} and {maxValue}", msgTitle);
                tb.SelectAll();
                tb.Focus();
                isValid = false;
            }
            return isValid;
        }
        /// <summary>
        /// checks if a textbox contains a decimal number within range
        /// </summary>
        /// <param name="tb">textbox to validate</param>
        /// <param name="minValue">minimum value allowed</param>
        /// <param name="maxValue">maximum value allowed</param>
        /// <returns>true if valid, and false if not</returns>
        public static bool IsDecimalInRange(TextBox tb, decimal minValue, decimal maxValue, String msgTitle)
        {
            bool isValid = true;
            decimal value;
            if (!Decimal.TryParse(tb.Text, out value)) // if the content cannot be  parsed as int
            {
                MessageBox.Show(tb.Tag + " has to be a decimal type.", msgTitle);
                tb.SelectAll();
                tb.Focus();
                isValid = false;
            }
            else if (value < minValue || value > maxValue) // decimal, but outside the range
            {
                MessageBox.Show(tb.Tag + $" has to be between {minValue} and {maxValue}", msgTitle);
                tb.SelectAll();
                tb.Focus();
                isValid = false;
            }
            return isValid;
        }


        /// <summary>
        /// checks if a textbox contains a number (possibly with decimal part)
        /// that is greater than or equal to zero
        /// </summary>
        /// <param name="tb">textbox to validate</param>
        /// <returns>true if valid, and false if not</returns>
        public static bool IsNonNegativeDouble(TextBox tb, String msgTitle)
        {
            bool isValid = true;
            double value;
            if (!Double.TryParse(tb.Text, out value)) // if the content cannot be  parsed as double
            {
                MessageBox.Show(tb.Tag + " has to be a number.", msgTitle);
                tb.SelectAll();
                tb.Focus();
                isValid = false;
            }
            else if (value < 0) // double, but negative
            {
                MessageBox.Show(tb.Tag + " cannot be negative.", msgTitle);
                tb.SelectAll();
                tb.Focus();
                isValid = false;
            }
            else if (value == 0)
            {
                MessageBox.Show(tb.Tag + " cannot be zero.", msgTitle);
                tb.SelectAll();
                tb.Focus();
                isValid = false;
            }
            return isValid;
        }


        /// <summary>
        /// checks if a textbox contains a number (possibly with decimal part)
        /// that is greater than or equal to zero
        /// </summary>
        /// <param name="tb">textbox to validate</param>
        /// <returns>true if valid, and false if not</returns>
        public static bool IsNonNegativeDecimal(TextBox tb, String msgTitle)
        {
            bool isValid = true;
            decimal value;
            if (!Decimal.TryParse(tb.Text, out value)) // if the content cannot be  parsed as double
            {
                MessageBox.Show(tb.Tag + " has to be a number.", msgTitle);
                tb.SelectAll();
                tb.Focus();
                isValid = false;
            }
            else if (value < 0) // double, but negative
            {
                MessageBox.Show(tb.Tag + " cannot be negative.", msgTitle);
                tb.SelectAll();
                tb.Focus();
                isValid = false;
            }
            return isValid;
        }
    }
}
