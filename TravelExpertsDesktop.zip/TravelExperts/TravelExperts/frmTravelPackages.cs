﻿
using System;
using System.Collections.Generic;

using System.Windows.Forms;
using TravelExpertsData;

namespace TravelExperts
{

    public partial class frmTravelPackages : Form
    {
        private List<PackageDTO> packages;
        public Package package;
        public frmTravelPackages()
        {
            InitializeComponent();
        }

        private void frmTravelPackages_Load(object sender, EventArgs e)
        {

            GetPackages();
            FormatGrid();


        }
        /* Method: GetPackages()
         * Purpose: To get a list of packages to bind to the grid
         * Author: Salah
        */
        private void GetPackages()
        {
            try
            {
                packages = PackageManager.GetPackages();
                dgvPackages.DataSource = packages;
            }
            catch (Exception ex)
            {

                MessageBox.Show($"Error when retrieving packages: {ex.Message}",
                           ex.GetType().ToString());
            }


        }


        /* Method: FormatGrid
         * Purpose: To format the data grid
         * Author: Salah
         */
        private void FormatGrid()
        {
            // Columns formating
            dgvPackages.Columns[0].Visible = false;
            dgvPackages.Columns[1].HeaderText = "Package Name";
            dgvPackages.Columns[1].Width = 200;
            dgvPackages.Columns[2].HeaderText = "Start Date";
            dgvPackages.Columns[2].Width = 160;
            dgvPackages.Columns[2].DefaultCellStyle.Format = "dd-MMM-yyyy";
            dgvPackages.Columns[3].HeaderText = "End Date";
            dgvPackages.Columns[3].Width = 160;
            dgvPackages.Columns[3].DefaultCellStyle.Format = "dd-MMM-yyyy";
            dgvPackages.Columns[4].HeaderText = "Description";
            dgvPackages.Columns[4].Width = 450;
            dgvPackages.Columns[5].HeaderText = "Base Price";
            dgvPackages.Columns[5].DefaultCellStyle.Format = "c";
            dgvPackages.Columns[6].HeaderText = "Commission";
            dgvPackages.Columns[6].DefaultCellStyle.Format = "c";
            dgvPackages.Columns[7].Visible = false;

        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvPackages.SelectedRows.Count != 0)
            {
                //dgvPackages.Rows.RemoveAt(rowIndex);
                string delPackage = dgvPackages.CurrentRow.Cells[1].Value.ToString();
                int dPkgId = Convert.ToInt32(dgvPackages.CurrentRow.Cells[0].Value);

                DialogResult answer = MessageBox.Show($"Are you sure to delete {delPackage}?",
                    "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (answer == DialogResult.Yes) // confirmed
                {
                    try
                    {
                        PackageManager.delPackage(dPkgId);
                        GetPackages();
                        MessageBox.Show($"{delPackage} is now deleted!");
                    }

                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error when deleting package: {ex.Message}",
                                        ex.GetType().ToString());
                    }

                }

                else
                {
                    MessageBox.Show("Delete Cancelled");
                }

            }
            else
            {
                MessageBox.Show("Please select a package to delete.", "Invalid Selection");
            }




        }
        /* Loads form to create a package 
         * Author: Priya P
         * Date: 30Sep2021
         */
        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmPackage PackageForm = new frmPackage();
            PackageForm.isAdd = true;
            
            PackageForm.Show();

        }
        /* Loads form to update a package 
         * Author: Priya P
         * Date: 30Sep2021
         */
        private void btnModify_Click(object sender, EventArgs e)
        {
            if (dgvPackages.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a package to modify.", "Invalid Selection");
            }
            else
            {

                int pkgId = Convert.ToInt32(dgvPackages.CurrentRow.Cells[0].Value);
                frmPackage PackageForm = new frmPackage();
                PackageForm.isAdd = false;
                PackageForm.PackageId = pkgId;
                
                
                if ((DateTime)dgvPackages.CurrentRow.Cells[2].Value < DateTime.Now)
                    PackageForm.Enabled = false;
                PackageForm.Show();
            }
            
                
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            GetPackages();
        }
    } // class end
} // namespace end
