﻿
namespace TravelExperts
{
    partial class frmPackage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPackage));
            this.txtPackageId = new System.Windows.Forms.TextBox();
            this.txtPkgName = new System.Windows.Forms.TextBox();
            this.lblPackageId = new System.Windows.Forms.Label();
            this.lblPackageName = new System.Windows.Forms.Label();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.txtPkgDesc = new System.Windows.Forms.TextBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblStarting = new System.Windows.Forms.Label();
            this.lblEnding = new System.Windows.Forms.Label();
            this.lblBasePrice = new System.Windows.Forms.Label();
            this.txtBasePrice = new System.Windows.Forms.TextBox();
            this.lblCommission = new System.Windows.Forms.Label();
            this.txtCommission = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblPackageInfo = new System.Windows.Forms.Label();
            this.pnlPackageDetails = new System.Windows.Forms.Panel();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lvwPackageProducts = new System.Windows.Forms.ListView();
            this.lblSupplier = new System.Windows.Forms.Label();
            this.lstProductSupplier = new System.Windows.Forms.ListBox();
            this.lblProducts = new System.Windows.Forms.Label();
            this.lstProducts = new System.Windows.Forms.ListBox();
            this.txtImageLocation = new System.Windows.Forms.TextBox();
            this.lblImgLocation = new System.Windows.Forms.Label();
            this.pnlPackageDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtPackageId
            // 
            this.txtPackageId.BackColor = System.Drawing.Color.White;
            this.txtPackageId.Enabled = false;
            this.txtPackageId.Location = new System.Drawing.Point(115, 44);
            this.txtPackageId.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPackageId.Name = "txtPackageId";
            this.txtPackageId.ReadOnly = true;
            this.txtPackageId.Size = new System.Drawing.Size(83, 27);
            this.txtPackageId.TabIndex = 10;
            this.txtPackageId.TabStop = false;
            // 
            // txtPkgName
            // 
            this.txtPkgName.BackColor = System.Drawing.Color.White;
            this.txtPkgName.Location = new System.Drawing.Point(112, 84);
            this.txtPkgName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPkgName.MaxLength = 50;
            this.txtPkgName.Name = "txtPkgName";
            this.txtPkgName.Size = new System.Drawing.Size(370, 27);
            this.txtPkgName.TabIndex = 0;
            this.txtPkgName.Tag = "Package Name";
            this.txtPkgName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPkgName_KeyPress);
            // 
            // lblPackageId
            // 
            this.lblPackageId.AutoSize = true;
            this.lblPackageId.Location = new System.Drawing.Point(26, 47);
            this.lblPackageId.Name = "lblPackageId";
            this.lblPackageId.Size = new System.Drawing.Size(85, 20);
            this.lblPackageId.TabIndex = 2;
            this.lblPackageId.Text = "Package ID:";
            // 
            // lblPackageName
            // 
            this.lblPackageName.AutoSize = true;
            this.lblPackageName.Location = new System.Drawing.Point(58, 88);
            this.lblPackageName.Name = "lblPackageName";
            this.lblPackageName.Size = new System.Drawing.Size(52, 20);
            this.lblPackageName.TabIndex = 3;
            this.lblPackageName.Text = "Name:";
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.CalendarMonthBackground = System.Drawing.Color.LavenderBlush;
            this.dtpStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpStartDate.Location = new System.Drawing.Point(111, 196);
            this.dtpStartDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dtpStartDate.MinDate = new System.DateTime(2021, 1, 1, 0, 0, 0, 0);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(113, 27);
            this.dtpStartDate.TabIndex = 2;
            this.dtpStartDate.Tag = "Start Date";
            // 
            // dtpEndDate
            // 
            this.dtpEndDate.CalendarMonthBackground = System.Drawing.Color.LavenderBlush;
            this.dtpEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEndDate.Location = new System.Drawing.Point(369, 196);
            this.dtpEndDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dtpEndDate.Name = "dtpEndDate";
            this.dtpEndDate.Size = new System.Drawing.Size(110, 27);
            this.dtpEndDate.TabIndex = 3;
            this.dtpEndDate.Tag = "End Date";
            // 
            // txtPkgDesc
            // 
            this.txtPkgDesc.BackColor = System.Drawing.Color.White;
            this.txtPkgDesc.Location = new System.Drawing.Point(111, 123);
            this.txtPkgDesc.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPkgDesc.MaxLength = 50;
            this.txtPkgDesc.Multiline = true;
            this.txtPkgDesc.Name = "txtPkgDesc";
            this.txtPkgDesc.Size = new System.Drawing.Size(370, 61);
            this.txtPkgDesc.TabIndex = 1;
            this.txtPkgDesc.Tag = "Package Description";
            this.txtPkgDesc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPkgDesc_KeyPress);
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(21, 126);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(88, 20);
            this.lblDescription.TabIndex = 7;
            this.lblDescription.Text = "Description:";
            // 
            // lblStarting
            // 
            this.lblStarting.AutoSize = true;
            this.lblStarting.Location = new System.Drawing.Point(24, 200);
            this.lblStarting.Name = "lblStarting";
            this.lblStarting.Size = new System.Drawing.Size(87, 20);
            this.lblStarting.TabIndex = 8;
            this.lblStarting.Text = "Starting On:";
            // 
            // lblEnding
            // 
            this.lblEnding.AutoSize = true;
            this.lblEnding.Location = new System.Drawing.Point(280, 200);
            this.lblEnding.Name = "lblEnding";
            this.lblEnding.Size = new System.Drawing.Size(81, 20);
            this.lblEnding.TabIndex = 9;
            this.lblEnding.Text = "Ending On:";
            // 
            // lblBasePrice
            // 
            this.lblBasePrice.AutoSize = true;
            this.lblBasePrice.Location = new System.Drawing.Point(18, 236);
            this.lblBasePrice.Name = "lblBasePrice";
            this.lblBasePrice.Size = new System.Drawing.Size(91, 20);
            this.lblBasePrice.TabIndex = 10;
            this.lblBasePrice.Text = "Base Price: $";
            // 
            // txtBasePrice
            // 
            this.txtBasePrice.BackColor = System.Drawing.Color.White;
            this.txtBasePrice.Location = new System.Drawing.Point(110, 233);
            this.txtBasePrice.MaxLength = 7;
            this.txtBasePrice.Name = "txtBasePrice";
            this.txtBasePrice.Size = new System.Drawing.Size(114, 27);
            this.txtBasePrice.TabIndex = 4;
            this.txtBasePrice.Tag = "Base Price";
            this.txtBasePrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtBasePrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBasePrice_KeyPress);
            // 
            // lblCommission
            // 
            this.lblCommission.AutoSize = true;
            this.lblCommission.Location = new System.Drawing.Point(268, 236);
            this.lblCommission.Name = "lblCommission";
            this.lblCommission.Size = new System.Drawing.Size(105, 20);
            this.lblCommission.TabIndex = 12;
            this.lblCommission.Text = "Commission: $";
            // 
            // txtCommission
            // 
            this.txtCommission.BackColor = System.Drawing.Color.White;
            this.txtCommission.Location = new System.Drawing.Point(369, 233);
            this.txtCommission.MaxLength = 6;
            this.txtCommission.Name = "txtCommission";
            this.txtCommission.Size = new System.Drawing.Size(110, 27);
            this.txtCommission.TabIndex = 5;
            this.txtCommission.Tag = "Commission";
            this.txtCommission.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCommission.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCommission_KeyPress);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(593, 79);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(87, 35);
            this.btnSave.TabIndex = 10;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(593, 138);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(87, 35);
            this.btnClear.TabIndex = 11;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(593, 194);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(87, 35);
            this.btnClose.TabIndex = 12;
            this.btnClose.Text = "C&lose";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblPackageInfo
            // 
            this.lblPackageInfo.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPackageInfo.Location = new System.Drawing.Point(0, 5);
            this.lblPackageInfo.Name = "lblPackageInfo";
            this.lblPackageInfo.Size = new System.Drawing.Size(704, 26);
            this.lblPackageInfo.TabIndex = 17;
            this.lblPackageInfo.Text = "Package Information";
            this.lblPackageInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlPackageDetails
            // 
            this.pnlPackageDetails.Controls.Add(this.btnRemove);
            this.pnlPackageDetails.Controls.Add(this.btnAdd);
            this.pnlPackageDetails.Controls.Add(this.lvwPackageProducts);
            this.pnlPackageDetails.Controls.Add(this.lblSupplier);
            this.pnlPackageDetails.Controls.Add(this.lstProductSupplier);
            this.pnlPackageDetails.Controls.Add(this.lblProducts);
            this.pnlPackageDetails.Controls.Add(this.lstProducts);
            this.pnlPackageDetails.Location = new System.Drawing.Point(5, 308);
            this.pnlPackageDetails.Name = "pnlPackageDetails";
            this.pnlPackageDetails.Size = new System.Drawing.Size(680, 357);
            this.pnlPackageDetails.TabIndex = 7;
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(602, 226);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(71, 30);
            this.btnRemove.TabIndex = 14;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(604, 43);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(69, 29);
            this.btnAdd.TabIndex = 9;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lvwPackageProducts
            // 
            this.lvwPackageProducts.BackColor = System.Drawing.Color.White;
            this.lvwPackageProducts.FullRowSelect = true;
            this.lvwPackageProducts.GridLines = true;
            this.lvwPackageProducts.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvwPackageProducts.HideSelection = false;
            this.lvwPackageProducts.Location = new System.Drawing.Point(14, 226);
            this.lvwPackageProducts.MultiSelect = false;
            this.lvwPackageProducts.Name = "lvwPackageProducts";
            this.lvwPackageProducts.Size = new System.Drawing.Size(582, 125);
            this.lvwPackageProducts.TabIndex = 13;
            this.lvwPackageProducts.UseCompatibleStateImageBehavior = false;
            this.lvwPackageProducts.View = System.Windows.Forms.View.Details;
            // 
            // lblSupplier
            // 
            this.lblSupplier.AutoSize = true;
            this.lblSupplier.Location = new System.Drawing.Point(336, 13);
            this.lblSupplier.Name = "lblSupplier";
            this.lblSupplier.Size = new System.Drawing.Size(119, 20);
            this.lblSupplier.TabIndex = 28;
            this.lblSupplier.Text = "Product Supplier";
            // 
            // lstProductSupplier
            // 
            this.lstProductSupplier.BackColor = System.Drawing.Color.White;
            this.lstProductSupplier.FormattingEnabled = true;
            this.lstProductSupplier.ItemHeight = 20;
            this.lstProductSupplier.Location = new System.Drawing.Point(251, 43);
            this.lstProductSupplier.Name = "lstProductSupplier";
            this.lstProductSupplier.Size = new System.Drawing.Size(345, 164);
            this.lstProductSupplier.TabIndex = 8;
            // 
            // lblProducts
            // 
            this.lblProducts.AutoSize = true;
            this.lblProducts.Location = new System.Drawing.Point(18, 10);
            this.lblProducts.Name = "lblProducts";
            this.lblProducts.Size = new System.Drawing.Size(66, 20);
            this.lblProducts.TabIndex = 26;
            this.lblProducts.Text = "Products";
            // 
            // lstProducts
            // 
            this.lstProducts.BackColor = System.Drawing.Color.White;
            this.lstProducts.FormattingEnabled = true;
            this.lstProducts.ItemHeight = 20;
            this.lstProducts.Location = new System.Drawing.Point(14, 43);
            this.lstProducts.Name = "lstProducts";
            this.lstProducts.Size = new System.Drawing.Size(220, 164);
            this.lstProducts.TabIndex = 7;
            this.lstProducts.Click += new System.EventHandler(this.lstProducts_Click);
            // 
            // txtImageLocation
            // 
            this.txtImageLocation.BackColor = System.Drawing.Color.White;
            this.txtImageLocation.Location = new System.Drawing.Point(109, 271);
            this.txtImageLocation.Name = "txtImageLocation";
            this.txtImageLocation.Size = new System.Drawing.Size(370, 27);
            this.txtImageLocation.TabIndex = 6;
            // 
            // lblImgLocation
            // 
            this.lblImgLocation.AutoSize = true;
            this.lblImgLocation.Location = new System.Drawing.Point(-2, 275);
            this.lblImgLocation.Name = "lblImgLocation";
            this.lblImgLocation.Size = new System.Drawing.Size(112, 20);
            this.lblImgLocation.TabIndex = 20;
            this.lblImgLocation.Text = "Image Location";
            // 
            // frmPackage
            // 
            this.AcceptButton = this.btnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(691, 667);
            this.Controls.Add(this.txtImageLocation);
            this.Controls.Add(this.pnlPackageDetails);
            this.Controls.Add(this.lblPackageInfo);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtCommission);
            this.Controls.Add(this.lblCommission);
            this.Controls.Add(this.txtBasePrice);
            this.Controls.Add(this.lblBasePrice);
            this.Controls.Add(this.lblEnding);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.txtPkgDesc);
            this.Controls.Add(this.dtpEndDate);
            this.Controls.Add(this.dtpStartDate);
            this.Controls.Add(this.lblPackageName);
            this.Controls.Add(this.lblPackageId);
            this.Controls.Add(this.txtPkgName);
            this.Controls.Add(this.txtPackageId);
            this.Controls.Add(this.lblImgLocation);
            this.Controls.Add(this.lblStarting);
            this.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmPackage";
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Package Information";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.frmPackage_Load);
            this.pnlPackageDetails.ResumeLayout(false);
            this.pnlPackageDetails.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPackageId;
        private System.Windows.Forms.TextBox txtPkgName;
        private System.Windows.Forms.Label lblPackageId;
        private System.Windows.Forms.Label lblPackageName;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.TextBox txtPkgDesc;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblStarting;
        private System.Windows.Forms.Label lblEnding;
        private System.Windows.Forms.Label lblBasePrice;
        private System.Windows.Forms.TextBox txtBasePrice;
        private System.Windows.Forms.Label lblCommission;
        private System.Windows.Forms.TextBox txtCommission;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblPackageInfo;
        private System.Windows.Forms.Panel pnlPackageDetails;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.ListView lvwPackageProducts;
        private System.Windows.Forms.Label lblSupplier;
        private System.Windows.Forms.ListBox lstProductSupplier;
        private System.Windows.Forms.Label lblProducts;
        private System.Windows.Forms.ListBox lstProducts;
        private System.Windows.Forms.TextBox txtImageLocation;
        private System.Windows.Forms.Label lblImgLocation;
    }
}