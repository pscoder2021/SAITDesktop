USE [TravelExperts]
GO

/****** Object:  View [dbo].[vw_PackageProductSuppliers]    Script Date: 20-Sep-21 12:45:26 AM ******/
DROP VIEW [dbo].[vw_PackageProductSuppliers]
GO

/****** Object:  View [dbo].[vw_PackageProductSuppliers]    Script Date: 20-Sep-21 12:45:26 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_PackageProductSuppliers]
AS
SELECT pps.PackageId, pps.ProductSupplierId, ps.ProductId, p.ProdName, ps.SupplierId, s.SupName
  FROM dbo.Packages_Products_Suppliers pps
		JOIN
		dbo.Products_Suppliers ps ON ps.ProductSupplierId = pps.ProductSupplierId
		JOIN
		dbo.Products p ON p.ProductId = ps.ProductId
		JOIN
		dbo.Suppliers s ON ps.SupplierId = s.SupplierId;
GO


