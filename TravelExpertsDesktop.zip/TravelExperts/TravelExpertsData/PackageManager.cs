﻿/* Name: PackageManager.cs
 * Purpose: To add/modify/delete/display packages from the Package table
 * Date: 15Sep2021
 * Author: Priya
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelExpertsData
{
    public class PackageManager
    {

        /* Function: GetPackages()
         * Purpose: To get all packages from the Packages table (Light Weight)
         * Author: Priya P 
         * Date: 15Sep2021
         */
        /// <summary>
        /// List of all packages as lightweight objects
        /// </summary>
        /// <returns>list </returns>
        public static List<PackageDTO> GetPackages()
        {
            List<PackageDTO> packages = null;
            using (TravelExpertsContext db = new TravelExpertsContext())
            {
                packages = db.Packages.Select(pkg => new PackageDTO
                                                {   PackageId = pkg.PackageId,
                                                    PkgName = pkg.PkgName,
                                                    PkgDesc = pkg.PkgDesc,
                                                    PkgStartDate = pkg.PkgStartDate,
                                                    PkgEndDate = pkg.PkgEndDate,
                                                    PkgBasePrice = pkg.PkgBasePrice,
                                                    PkgAgencyCommission = pkg.PkgAgencyCommission,
                                                    PkgImageLocation = pkg.PkgImageLocation
                                                }).ToList();
            }
            return packages;
        }//end Package DTO list

        /* Function: GetPackage()
         * Purpose: To get one package from the Packages table 
         * Parameter: pkgId (int) - PackageId
         * Author: Priya P 
         * Date: 15Sep2021
         */
        /// <summary>
        /// retrieves data of one package based on id
        /// </summary>
        /// <param name="pkgId"> PackageId</param>
        /// <returns>Package object or null if not found</returns>
        public static Package GetPackage(int pkgId)
        {
            Package package;
            using (TravelExpertsContext db = new TravelExpertsContext())
            {
                package = db.Packages.Find(pkgId);//find the package details by id
            }
            return package;
        }//end Get Package

        public static List<PackageProductsSuppliersDTO> GetPackageProductsSuppliers(int pkgId)
        
        {
            List<PackageProductsSuppliersDTO> packageProductsSuppliers = null;

            using (TravelExpertsContext db = new TravelExpertsContext())
            {
                packageProductsSuppliers = db.VwPackageProductSuppliers.Where(pps => pps.PackageId == pkgId)
                
                                                 .Select(pps =>  new PackageProductsSuppliersDTO
                                                     {PackageId = pps.PackageId,
                                                      ProductSupplierId = pps.ProductSupplierId,
                                                      ProdName = pps.ProdName,
                                                      SupName = pps.SupName
                                                  }).ToList();
                 
            }
            return packageProductsSuppliers;
        } //end list 
        
        
        /* Function: addPackage()
         * Purpose: To add package to the Packages table 
         * Parameter: nPkgId (int) - PackageId
         * Author: Priya P 
         * Date: 11Sep2021
         */
        /// <summary>
        /// To save a new package into Packages table
        /// </summary>
        /// <param name="nPkg">Package to save</param>
        public static int addPackage(Package nPkg)
        {
            int PackageId = 0;
            using (TravelExpertsContext db = new TravelExpertsContext())
            {
                db.Packages.Add(nPkg);
                db.SaveChanges();
                PackageId = nPkg.PackageId;
            }
            return PackageId;
        }//end addPackage

        /// <summary>
        /// To delete a package from Packages table
        /// </summary>
        /// <param name="dPkg"></param>
        public static void delPackage(int dPkgId)
        {
            using (TravelExpertsContext db = new TravelExpertsContext())
            {
                Package dPackage = db.Packages.Find(dPkgId);
                delPackagePdtsSuppliers(dPkgId);
                db.Packages.Remove(dPackage);
                db.SaveChanges();
            }
        }//end delPackage

        public static void updatePackage(Package uPkg)
        {
            Package oPkg;//original package
            using (TravelExpertsContext db = new TravelExpertsContext())
            {
                oPkg = db.Packages.Find(uPkg.PackageId); //Package to be updated.
                UpdatePackageData(oPkg, uPkg);//copy new data into original data object.
                db.SaveChanges();//save changes to db

            }
        }//end update package

        /* Method: UpdatePackageData
         * Parameters: oPkg, nPkg - packages for original and modified data
         * Purpose: updates original package information with updated information
         */
        private static void UpdatePackageData(Package oPkg, Package nPkg)
        {
            if (oPkg != null && nPkg != null)
            {
                oPkg.PkgName = nPkg.PkgName;
                oPkg.PkgDesc = nPkg.PkgDesc;
                oPkg.PkgStartDate = nPkg.PkgStartDate;
                oPkg.PkgEndDate = nPkg.PkgEndDate;
                oPkg.PkgBasePrice = nPkg.PkgBasePrice;
                oPkg.PkgAgencyCommission = nPkg.PkgAgencyCommission;
                oPkg.PkgImageLocation = nPkg.PkgImageLocation;
            }
        }//end updatePackageData

        public static void addPackagePdtsSuppliers(List<PackagesProductsSupplier> pps)
        {
            using (TravelExpertsContext db = new TravelExpertsContext())
            {
                //db.PackagesProductsSuppliers.
                db.PackagesProductsSuppliers.AddRange(pps);
                db.SaveChanges();
                
            }
        }

        public static void delPackagePdtsSuppliers(int pkgId)
        {
            using (TravelExpertsContext db = new TravelExpertsContext())
            {
                db.PackagesProductsSuppliers.RemoveRange(db.PackagesProductsSuppliers.Where(pps => pps.PackageId == pkgId));
                db.SaveChanges();

            }
        }
        
    }//end class
}//end namespace
