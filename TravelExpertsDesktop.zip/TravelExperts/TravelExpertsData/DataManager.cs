﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * DataManager - Class to add/modify/delete items in the database
 * David Grant
 * 2021/09/16
 */

namespace TravelExpertsData
{
    public class DataManager
    {
        /// <summary>
        /// addItem to database - Product and ProductSupplier
        /// </summary>
        /// <param name="prod"></param>
        /// <param name="sup"></param>
        public void addItem(Product prod, Supplier sup)
        {

            using (TravelExpertsContext db = new TravelExpertsContext())
            {
                db.Suppliers.Add(sup);
                ProductsSupplier ps = new ProductsSupplier();

                ps.ProductId = prod.ProductId;
                ps.SupplierId = sup.SupplierId;
                db.ProductsSuppliers.Add(ps);
                
                db.SaveChanges();
            }

        }

        /// <summary>
        /// modifyItem in database - Product and ProductSupplier
        /// </summary>
        /// <param name="prod"></param>
        /// <param name="sup"></param>
        /// <param name="prodSup"></param>
        public void modifyItem(Product prod, Supplier sup, ProductsSupplier prodSup)
        {

            using (TravelExpertsContext db = new TravelExpertsContext())
            {
                ProductsSupplier ps = new ProductsSupplier();
                ps.ProductId = prod.ProductId;
                ps.SupplierId = sup.SupplierId;

                var oldSupplier = db.Suppliers.Find(sup.SupplierId);
                var oldProdSup = db.ProductsSuppliers.Find(prodSup.ProductSupplierId);
                
                oldSupplier.SupName = sup.SupName;
                oldProdSup.ProductId = prod.ProductId;
                oldProdSup.SupplierId = sup.SupplierId;

                db.SaveChanges();

            }

        }

        /// <summary>
        /// deleteItem in database - ProductSupplier
        /// </summary>
        /// <param name="prod"></param>
        /// <param name="sup"></param>
        /// <param name="prodSup"></param>
        public void deleteItem(Product prod, Supplier sup, ProductsSupplier prodSup)
        {

            using (TravelExpertsContext db = new TravelExpertsContext())
            {
                var productSup = db.ProductsSuppliers.Find(prodSup.ProductSupplierId);
                db.ProductsSuppliers.Remove(productSup);

                db.SaveChanges();
            }

        }
    }
}
