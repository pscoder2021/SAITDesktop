﻿/* Name: ProductManager.cs
 * Purpose: To get details of Products and Products_Suppliers tables
 * Date: 19Sep2021
 * Author: Priya
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelExpertsData
{
    public class ProductManager
    {
        /* Function:  GetProducts()
        * Purpose: DTO to bring a list of products from the Products Table
        * Uses: ProductDTO
        * Author: Priya P 
        * Date: 19Sep2021
        */


        /// <summary>
        /// To get a list of all products (DTO) from Products table
        /// </summary>
        /// <returns>List of Products</returns>
        public static List<ProductDTO> GetProducts()
        {
            List<ProductDTO> products = null;
            using (TravelExpertsContext db = new TravelExpertsContext())
            {

                products = db.Products.Select( pdt => new ProductDTO
                                                    {
                                                        ProductId = pdt.ProductId,
                                                        ProdName = pdt.ProdName
                                                    }).OrderBy(p=>p.ProdName).ToList();  
             
            }
            return products;
        }//end list
        /* Function:  addProduct()
        * Purpose: Add a product to the Products Table
        * Parameter: nPdt as Product object
        * Author: Priya P 
        * Date: 19Sep2021
        */
        /// <summary>
        /// Add a new product
        /// </summary>
        /// <param name="nPdt">new Product object</param>
        public static int addProduct(Product nPdt)
        {
            int ProductId = 0;
            using (TravelExpertsContext db = new TravelExpertsContext())
            {

                    db.Products.Add(nPdt);//add the new product
                    db.SaveChanges();
                    ProductId = nPdt.ProductId;
            }
            return ProductId;

        }//end add Product
        /* Function:  updateProduct()
        * Purpose: Update a product in the Products Table
        * Parameter: ProductId as int, ProdName as string
        * Author: Priya P 
        * Date: 19Sep2021
        */
        /// <summary>
        /// update an existing product
        /// </summary>
        /// <param name="ProductId">old product id</param>
        /// <param name="ProdName">updated product name</param>
        public static void updateProduct(int ProductId, string ProdName)
        {
            Product oPdt;//original product
            using (TravelExpertsContext db = new TravelExpertsContext())
            {

                oPdt = db.Products.Find(ProductId); //Product to be updated.
                oPdt.ProdName = ProdName;//new product name
                db.SaveChanges();//save changes to db
            }
        }
        /* Function:  delProduct()
        * Purpose: Delete a product in the Products Table
        * Parameter: ProductId as int
        * Author: Priya P 
        * Date: 19Sep2021
        */
        /// <summary>
        /// Delete a product
        /// </summary>
        /// <param name="ProductId">Product Id as int</param>
        public static void delProduct(int ProductId)
        {
            Product oPdt;//original product
            using (TravelExpertsContext db = new TravelExpertsContext())
            {

                oPdt = db.Products.Find(ProductId); //Product to be updated.
                db.Products.Remove(oPdt);//delete product
                db.SaveChanges();//save changes to db
            }
        }
        /* Function:  prodDependencies()
        * Purpose: check if a product has dependencies
        * Parameter: ProductId as int
        * Author: Priya P 
        * Date: 19Sep2021
        */
        /// <summary>
        /// Checks if a product is already used.
        /// </summary>
        /// <param name="ProductId">Product Id as int</param>
        /// <returns>bool</returns>
        public static bool prodDependencies(int ProductId)
        {
            bool isRemovable = true;
            int pdtCount = 0;
            using (TravelExpertsContext db = new TravelExpertsContext())
            {
                pdtCount = db.ProductsSuppliers.Where(ps => ps.ProductId == ProductId).Count();
                if (pdtCount > 0)
                    isRemovable = false;
            }
            return isRemovable;
        }
        /* Function:  GetProductSuppliers()
        * Purpose: DTO to bring a list of product suppliers from the Products_Suppliers Table
        * Uses: ProductSuppliersDTO
        * Author: Priya P 
        * Date: 19Sep2021
        */
        /// <summary>
        /// Gets a list of all product suppliers
        /// </summary>
        /// <returns>list</returns>
        public static List<ProductSuppliersDTO> GetProductSuppliers()
        {
            List<ProductSuppliersDTO> productsSuppliers = null;

            using (TravelExpertsContext db = new TravelExpertsContext())
            {
                productsSuppliers = db.ProductsSuppliers.Select(ps => new ProductSuppliersDTO
                                                                {
                                                                    ProductSupplierId = ps.ProductSupplierId,
                                                                    ProductId = ps.ProductId,
                                                                    SupplierId = ps.SupplierId
                                                                 }).ToList();
                
            }

            return productsSuppliers;
        }

    }//class
}//namespace
