﻿/* Class - ProductSupplierDTO
 * Purpose - light weight object for ProductSuppliers
 * Author - Priya P
 * Date = 19-Sep-2021
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelExpertsData
{
    public class ProductSuppliersDTO
    {
        public int ProductSupplierId { get; set; }
        public int? ProductId { get; set; }
        public int? SupplierId { get; set; }
    }
}
