﻿/* Class - SupplierManager
 * Purpose - to get the list of suppliers from db
 * Author - Priya P
 * Date = 10-Sep-2021
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace TravelExpertsData
{
    public class SupplierManager
    {
        /* Function: GetSuppliers()
        * Purpose: To get all suppliers from the Suppliers table 
        * Author: Priya P 
        * Date: 16Sep2021
        */
        /// <summary>
        /// Returns a list of supplier Id and Name from the database
        /// </summary>
        /// <returns>supplier list</returns>
        public static List<Supplier> GetSuppliers()
        {
            List<Supplier> suppliers = null;

            using (TravelExpertsContext db = new TravelExpertsContext())
            {

                suppliers = db.Suppliers.Select(s => new Supplier
                {
                    SupplierId = s.SupplierId,
                    SupName = s.SupName
                }).OrderBy(s=>s.SupplierId).ToList();

            }
            return suppliers;
        }
    }
}
